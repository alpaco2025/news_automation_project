requirements.txt 파일 설명
------ 한 번에 로컬에서 우리 개발 관련된 라이브러리 설치 가능 -------

- requests → 뉴스 사이트 접속해서 HTML 가져오기
- beautifulsoup4 → HTML 파싱해서 제목/본문 추출
- pymysql → Python → MySQL(RDS/로컬) 연결
- python-dotenv → .env에서 OPENAI 키, DB 비번 읽기
- openai → 요약/토픽/키워드 생성 LLM 호출
- streamlit → 대시보드(UI)
- pandas → 통계/집계/표 만들 때 편하게 쓰는 용도 (있으면 좋음)
