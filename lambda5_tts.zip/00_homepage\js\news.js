console.log("news.js loaded (today + previous + POLLY TTS)");

// ================================
// DOM
// ================================
const todayGrid = document.getElementById("newsGrid");      // Today News
const pastGrid  = document.getElementById("pastNewsGrid"); // Previous News

const newsModal = document.getElementById("newsModal");
const modalClose = document.getElementById("newsModalClose");
const modalTitle = document.getElementById("modalTitle");
const modalSummary = document.getElementById("modalSummary");
const modalKeywords = document.getElementById("modalKeywords");

// ================================
// Config
// ================================
const TODAY_NEWS_LIMIT = 30;
const PREVIOUS_NEWS_LIMIT = 30;

// S3 base
const S3_BASE = "https://news-automation-public.s3.ap-northeast-2.amazonaws.com";

// JSON
const LATEST_URL = `${S3_BASE}/news/daily/latest.json`;

// ================================
// Date utils
// ================================
function getDateFolder(article, fallbackDate) {
  const ad = (article.article_date || "").trim();
  const fromArticleDate = ad.length >= 10 ? ad.slice(0, 10) : "";
  return fromArticleDate || article.date || fallbackDate || "";
}

function getToday() {
  return new Date().toISOString().slice(0, 10);
}

function getYesterday() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toISOString().slice(0, 10);
}

// ================================
// URL builders
// ================================
function getImageUrl(date, id) {
  return `${S3_BASE}/news/images/${date}/${id}.png`;
}

function getTtsUrl(date, id) {
  return `${S3_BASE}/news/tts/${date}/${id}.mp3`;
}

// ================================
// Helpers
// ================================
function escapeHtml(str = "") {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function stopAllAudio() {
  document.querySelectorAll("audio").forEach(a => {
    try {
      a.pause();
      a.currentTime = 0;
    } catch (_) {}
  });
}

// ================================
// Card
// ================================
function createNewsCard(article, fallbackDate) {
  const card = document.createElement("article");
  card.className = "card";

  const date = getDateFolder(article, fallbackDate);
  const imageUrl = getImageUrl(date, article.id);
  const ttsUrl = getTtsUrl(date, article.id);

  const keywordsHtml = (article.keywords || [])
    .map(k => `<span>#${escapeHtml(k)}</span>`)
    .join("");

  card.innerHTML = `
    <div class="news-card-image-wrap">
      <img class="news-thumb"
           src="${imageUrl}"
           alt=""
           onerror="this.parentElement.style.display='none'" />
      <div class="news-card-ai-label">AI로 생성된 이미지</div>
    </div>

    <div class="news-date">${escapeHtml(date)}</div>
    <div class="news-title">${escapeHtml(article.title || "")}</div>

    <div class="news-keywords">${keywordsHtml}</div>

    <!-- ✅ Polly TTS (MP3) -->
    <div class="news-tts-wrap" style="margin-top:10px; display:flex; gap:8px; align-items:center;">
      <audio class="news-tts-audio" controls preload="none" src="${ttsUrl}"
             onerror="this.style.display='none'"></audio>
    </div>
  `;

  // 카드 클릭 시 모달 오픈 (audio 클릭은 제외)
  card.addEventListener("click", (e) => {
    if (e.target && e.target.closest("audio")) return;
    openNewsModal(article, date);
  });

  return card;
}

// ================================
// Modal
// ================================
function openNewsModal(article, date) {
  const imageUrl = getImageUrl(date, article.id);
  const ttsUrl = getTtsUrl(date, article.id);

  // 기존 삽입 요소 제거(중복 방지)
  document
    .querySelectorAll(".news-modal-image-wrap, .modal-date-under-image, .news-modal-tts-wrap")
    .forEach(el => el.remove());

  // 1) 이미지 삽입
  modalTitle.insertAdjacentHTML(
    "beforebegin",
    `
    <div class="news-modal-image-wrap">
      <img class="news-modal-thumb"
           src="${imageUrl}"
           alt=""
           onerror="this.parentElement.style.display='none'" />
      <div class="news-modal-ai-label">AI로 생성된 이미지</div>
    </div>
    `
  );

  // 2) 날짜 삽입(이미지 바로 아래)
  const imageEl = document.querySelector(".news-modal-image-wrap");
  if (imageEl) {
    imageEl.insertAdjacentHTML(
      "afterend",
      `<div class="modal-date-under-image">${escapeHtml(date)}</div>`
    );
  }

  // 3) ✅ Polly TTS audio 삽입(날짜 아래)
  const dateEl = document.querySelector(".modal-date-under-image");
  if (dateEl) {
    dateEl.insertAdjacentHTML(
      "afterend",
      `
      <div class="news-modal-tts-wrap" style="margin:10px 0;">
        <audio controls preload="none" src="${ttsUrl}"
               onerror="this.style.display='none'"></audio>
      </div>
      `
    );
  }

  // 4) 제목/요약
  modalTitle.textContent = article.title || "";
  modalSummary.textContent = article.summary || "";

  // 5) 키워드
  modalKeywords.innerHTML = `
    <div class="news-keywords modal-keywords">
      ${(article.keywords || []).map(k => `<span>#${escapeHtml(k)}</span>`).join("")}
    </div>
  `;

  newsModal.classList.add("active");
}

// ================================
// Close modal
// ================================
modalClose.addEventListener("click", () => {
  stopAllAudio();
  newsModal.classList.remove("active");
});

newsModal.addEventListener("click", e => {
  if (e.target.classList.contains("news-modal-overlay")) {
    stopAllAudio();
    newsModal.classList.remove("active");
  }
});

// ================================
// Load news
// ================================
fetch(LATEST_URL)
  .then(res => {
    if (!res.ok) throw new Error("latest.json 응답 오류");
    return res.json();
  })
  .then(data => {
    const articles = data.articles || [];
    const fallbackDate = data.date || "";

    const today = getToday();
    const yesterday = getYesterday();

    if (articles.length === 0) {
      todayGrid.innerHTML = "<p>오늘 뉴스가 없습니다.</p>";
      pastGrid.innerHTML = "<p>이전 뉴스가 없습니다.</p>";
      return;
    }

    // 최신순 정렬
    articles.sort((a, b) => {
      const ta = new Date(a.article_date || a.date || fallbackDate);
      const tb = new Date(b.article_date || b.date || fallbackDate);
      return tb - ta;
    });

    todayGrid.innerHTML = "";
    pastGrid.innerHTML = "";

    const todayArticles = [];
    const pastArticles = [];

    articles.forEach(article => {
      const d = getDateFolder(article, fallbackDate);
      if (d === today || d === yesterday) {
        todayArticles.push(article);
      } else {
        pastArticles.push(article);
      }
    });

    todayArticles
      .slice(0, TODAY_NEWS_LIMIT)
      .forEach(a => todayGrid.appendChild(createNewsCard(a, fallbackDate)));

    pastArticles
      .slice(0, PREVIOUS_NEWS_LIMIT)
      .forEach(a => pastGrid.appendChild(createNewsCard(a, fallbackDate)));
  })
  .catch(err => {
    console.error("뉴스 로딩 실패:", err);
    todayGrid.innerHTML = "<p>뉴스를 불러오지 못했습니다.</p>";
    pastGrid.innerHTML = "<p>뉴스를 불러오지 못했습니다.</p>";
  });
