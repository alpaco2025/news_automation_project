import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from datetime import datetime
import re
import json

BASE_URL = "https://www.aitimes.com"


# ---------------------------------------------------------
# 보기 좋은 출력
# ---------------------------------------------------------
def pretty_print_article(article):
    print("\n" + "=" * 80)
    print(f"📰 제목: {article['title']}")
    print(f"📂 카테고리: {article['category']}")
    print(f"⏱ 날짜: {article['article_date']}")
    print(f"🔗 URL: {article['url']}")
    print("-" * 80)
    print("📝 본문 미리보기 (앞 200자):")
    print(article["content"][:200] + "...")
    print("=" * 80 + "\n")


# ---------------------------------------------------------
# 유니코드 제거
# ---------------------------------------------------------
def clean_invisible_chars(text):
    if not text:
        return ""
    for ch in ["\u200b", "\ufeff", "\u2060", "\u180e"]:
        text = text.replace(ch, "")
    return text.strip()


# ---------------------------------------------------------
# 날짜 파싱
# ---------------------------------------------------------
def extract_korean_date(text):
    if not text:
        return None

    text = text.replace("입력", "").strip()
    match = re.search(r"\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}", text)

    if not match:
        return None

    try:
        return datetime.strptime(match.group(), "%Y.%m.%d %H:%M")
    except:
        return None


# ---------------------------------------------------------
# 제목(title) 정리
# ---------------------------------------------------------
def clean_title(text):
    if not text:
        return ""

    text = text.replace("“", "\"").replace("”", "\"")
    text = text.replace("‘", "'").replace("’", "'")

    # 앞쪽 [브라켓] 제거
    text = re.sub(r"^\[[^\]]+\]\s*", "", text)

    # 제목 앞뒤의 과도한 따옴표 제거
    text = re.sub(r'^"+', '', text)
    text = re.sub(r'"+$', '', text)

    # 내부 누적 따옴표 정리
    text = re.sub(r'""+', '"', text)

    return text.strip()


# ---------------------------------------------------------
# 본문(content) 전처리 – 전체 강화
# ---------------------------------------------------------
def clean_article_body(text):
    if not text:
        return ""

    # 1) 서론/광고 제거
    remove_patterns = [
        r"기사를\s*읽어드립니다\.?",
        r"AI타임스입니다\.?",
        r"이\s*뉴스는\s*AI가\s*읽어드립니다\.?",
        r"\(사진\s*=\s*[^)]+\)",
        r"\(그래픽\s*=\s*[^)]+\)",
    ]
    for p in remove_patterns:
        text = re.sub(p, "", text)

    # 2) 기자 + 메일 제거
    text = re.sub(r"[가-힣]{2,10}\s*[A-Za-z0-9._%+-]+\s*\.\s*[A-Za-z]{2,4}", "", text)
    text = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+", "", text)
    text = re.sub(r"(기자|특파원)", "", text)

    # 3) 이어 XX일 주요 뉴스입니다 제거
    text = re.split(r"이어\s*\d+일\s*주요\s*뉴스입니다", text)[0]

    # 4) URL 제거
    url_patterns = [
        r"https?://\S+",
        r"pic\.twitter\.com/\S+",
        r"@[A-Za-z0-9_]+",
    ]
    for p in url_patterns:
        text = re.sub(p, "", text)

    # 5) 따옴표 정리
    text = text.replace("“", "\"").replace("”", "\"")
    text = text.replace("‘", "'").replace("’", "'")
    text = re.sub(r'""+', '"', text)

    # 6) 문장 분리
    text = re.sub(
        r"(?<=[.!?])\s*(?=[가-힣A-Za-z0-9])",
        "\n",
        text
    )

    # 7) 기타 제거
    garbage = ["저작권자 ©", "무단전재 및 재배포 금지", "관련기사", "추천기사", "△"]
    for g in garbage:
        text = text.replace(g, "")

    # 8) 공백 정리
    text = re.sub(r"\s{2,}", " ", text)
    text = re.sub(r"\n\s+", "\n", text)

    # 9) 마지막 라인 기자명 제거
    text = re.sub(r"\n?[가-힣]{2,3}\s*$", "", text).strip()

    return text.strip()


# ---------------------------------------------------------
# 본문 없는 기사 제외 조건
# ---------------------------------------------------------
def is_valid_article_content(text):
    if not text:
        return False
    if len(text) < 40:
        return False
    sentences = [s for s in text.split("\n") if s.strip()]
    if len(sentences) < 2:
        return False
    hangul = len(re.findall(r"[가-힣]", text))
    if hangul / max(len(text), 1) < 0.05:
        return False
    return True


# ---------------------------------------------------------
# 기사 URL 수집
# ---------------------------------------------------------
def get_article_urls(target_count=20):
    urls = []
    page = 1

    while len(urls) < target_count:
        list_url = f"{BASE_URL}/news/articleList.html?view_type=sm&page={page}"
        res = requests.get(list_url, headers={"User-Agent": "Mozilla/5.0"})
        soup = BeautifulSoup(res.text, "html.parser")

        for a in soup.select(".altlist-subject a"):
            href = a.get("href")
            if href and "articleView" in href:
                urls.append(urljoin(BASE_URL, href))

        print(f"📄 페이지 {page} → 누적 {len(urls)}개 URL 수집됨")
        page += 1

    return urls[:target_count]


# ---------------------------------------------------------
# 상세 페이지 크롤링
# ---------------------------------------------------------
def parse_article(url):
    res = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
    soup = BeautifulSoup(res.text, "html.parser")

    category = clean_invisible_chars(
        soup.select_one(".section").get_text(strip=True)
    ) if soup.select_one(".section") else ""

    title_raw = clean_invisible_chars(
        soup.select_one(".heading").get_text(strip=True)
    ) if soup.select_one(".heading") else ""
    title = clean_title(title_raw)

    date_tag = soup.select_one(".breadcrumbs li:nth-child(2)")
    article_date = extract_korean_date(date_tag.get_text(strip=True)) if date_tag else None

    body_tag = soup.select_one("#article-view-content-div")
    content_raw = clean_invisible_chars(
        body_tag.get_text(" ", strip=True)
    ) if body_tag else ""
    content = clean_article_body(content_raw)

    if not is_valid_article_content(content):
        print(f"⚠️ 본문 없음 → 제외: {url}")
        return None

    return {
        "url": url.strip(),
        "category": category.strip(),
        "title": title.strip(),
        "content": content.strip(),
        "article_date": article_date,
        "source": "AITimes"
    }


# ---------------------------------------------------------
# 실행
# ---------------------------------------------------------
def crawl_articles(target_count: int = 200):
    urls = get_article_urls(target_count=target_count)
    articles = []

    for u in urls:
        art = parse_article(u)
        if art:
            articles.append(art)

    return articles
